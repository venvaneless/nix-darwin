# darwin/packages/development-pkgs.nix
#
# =====================================================================
# PACKAGES: DEVELOPMENT TOOLS
#
# Installs development and document-building tools:
# - Git helpers
# - Nix language tooling
# - Docker CLI
# - Node.js and Python
# - Pandoc and LaTeX/PDF tooling
# - macOS development applications
# =====================================================================

{ lib, pkgs, ... }:

let
  # ------------------------------------------------------------
  # ------ CUSTOM TEX LIVE ENVIRONMENT ------ #
  # ------------------------------------------------------------

  # ---- Custom TeX Live environment
  # Combines a medium TeX Live scheme with extra LaTeX packages
  # needed by Pandoc and PDF workflows.
  myTex = pkgs.texlive.combine {
    inherit (pkgs.texlive) scheme-medium titlesec;
  };

  # ------------------------------------------------------------
  # ------ CUSTOM APPLICATION PACKAGES ------ #
  # ------------------------------------------------------------

  # ---- iTerm2
  iterm2Package = pkgs.callPackage ./iterm2 { };

  # ---- iTerm AI Plugin
  itermAiPluginPackage = pkgs.callPackage ./iterm2/iterm-ai-plugin.nix { };

  # ---- iTerm Browser Plugin
  itermBrowserPluginPackage = pkgs.callPackage ./iterm2/iterm-browser-plugin.nix { };

  # ------------------------------------------------------------
  # ------ DEVELOPMENT CLI PACKAGES ------ #
  # ------------------------------------------------------------

  developmentPackages = with pkgs; [
    # Password manager CLI
    bitwarden-cli

    # Git diff viewer
    delta

    # Container engine
    docker_29

    # Docker Compose
    docker-compose

    # Shell environment loader
    direnv

    # Update locally packaged flake outputs
    nix-update

    # Custom LaTeX environment
    myTex

    # macOS security certificate tools
    nssTools

    # Document converter
    pandoc

    # ------------------------------------------------
    ## Git tools

    # GitHub CLI for repositories, releases, pull requests, issues, and Actions
    gh

    # Git encrypted files
    git-crypt

    # Git history rewriting tools
    git-filter-repo

    # Git large file storage
    git-lfs

    # Terminal Git UI
    lazygit

    # ------------------------------------------------
    ## Code linters and formatters

    # Code formatter
    prettier

    # CSS/SCSS linter
    stylelint

    # Lua formatter
    stylua

    # ------------------------------------------------
    ## JavaScript tools

    # JavaScript runtime, bundler, transpiler and package manager
    bun

    # Event-driven I/O framework for JavaScript engine
    nodejs

    # ------------------------------------------------
    ## Python tools

    # Python interpreter
    python3

    # Python data analysis library
    python3Packages.pandas

    # Python PDF generation library
    python3Packages.reportlab

    # Python package installer and resolver
    uv
  ];

  # ------------------------------------------------------------
  # ------ DEVELOPMENT APPLICATIONS ------ #
  #
  # enable:
  #   Installs or removes the application package.
  #
  # link.enable:
  #   Creates or removes the categorized application symlink.
  # ------------------------------------------------------------

  developmentApplications = {
    # ---- iTerm2
    iterm2 = {
      displayName = "iTerm2";
      enable = true;
      package = iterm2Package;

      link = {
        enable = true;
        appName = "iTerm.app";
        targetDirectory = "/Applications/Programming";
      };
    };

    # ---- iTerm AI Plugin
    itermAiPlugin = {
      displayName = "iTerm AI Plugin";
      enable = true;
      package = itermAiPluginPackage;

      link = {
        enable = true;
        appName = "iTermAI.app";
        targetDirectory = "/Applications/Programming";
      };
    };

    # ---- iTerm Browser Plugin
    itermBrowserPlugin = {
      displayName = "iTerm Browser Plugin";
      enable = true;
      package = itermBrowserPluginPackage;

      link = {
        enable = true;
        appName = "iTermBrowserPlugin.app";
        targetDirectory = "/Applications/Programming";
      };
    };
  };

  # ------------------------------------------------------------
  # ------ ENABLED APPLICATION PACKAGES ------ #
  # ------------------------------------------------------------

  enabledDevelopmentApplicationPackages = map (application: application.package) (
    lib.filter (application: application.enable) (lib.attrValues developmentApplications)
  );

  # ------------------------------------------------------------
  # ------ MANAGED APPLICATION LINKS ------ #
  # ------------------------------------------------------------

  managedDevelopmentApplicationLinks = lib.filter (application: application ? link) (
    lib.attrValues developmentApplications
  );

  renderDevelopmentApplicationLink =
    application:

    let
      sourcePath = "/Applications/Nix Apps/${application.link.appName}";

      targetPath = "${application.link.targetDirectory}/${application.link.appName}";

      shouldExist = application.enable && application.link.enable;
    in

    ''
      manage_application_link \
        ${lib.escapeShellArg application.displayName} \
        ${lib.escapeShellArg sourcePath} \
        ${lib.escapeShellArg targetPath} \
        ${lib.escapeShellArg (if shouldExist then "true" else "false")}
    '';

  managedDevelopmentApplicationLinkCommands =
    lib.concatMapStringsSep "\n" renderDevelopmentApplicationLink
      managedDevelopmentApplicationLinks;

  # ------------------------------------------------------------
  # ------ APPLICATION LINK MANAGER ------ #
  # ------------------------------------------------------------

  manageDevelopmentApplicationLinks = pkgs.writeShellScriptBin "manage-darwin-development-application-links" ''
    set -euo pipefail

    manage_application_link() {
      local display_name="$1"
      local source_path="$2"
      local target_path="$3"
      local should_exist="$4"
      local target_directory
      local current_target

      target_directory="$(
        ${pkgs.coreutils}/bin/dirname -- "$target_path"
      )"

      if [ "$should_exist" = "true" ]; then
        if [ ! -d "$source_path" ]; then
          echo "[$display_name] ERROR: Nix-managed application was not found." >&2
          echo "[$display_name] Expected: $source_path" >&2
          return 1
        fi

        ${pkgs.coreutils}/bin/mkdir \
          -p \
          -- \
          "$target_directory"

        if [ -L "$target_path" ]; then
          current_target="$(
            ${pkgs.coreutils}/bin/readlink \
              -- \
              "$target_path"
          )"

          if [ "$current_target" = "$source_path" ]; then
            return 0
          fi

          echo "[$display_name] ERROR: Refusing to replace an unrelated link." >&2
          echo "[$display_name] Existing target: $current_target" >&2
          return 1
        fi

        if [ -e "$target_path" ]; then
          echo "[$display_name] ERROR: Refusing to replace an existing item." >&2
          echo "[$display_name] Existing item: $target_path" >&2
          return 1
        fi

        ${pkgs.coreutils}/bin/ln \
          -s \
          -- \
          "$source_path" \
          "$target_path"

        echo "[$display_name] Application link created."
        return 0
      fi

      if [ -L "$target_path" ]; then
        current_target="$(
          ${pkgs.coreutils}/bin/readlink \
            -- \
            "$target_path"
        )"

        if [ "$current_target" = "$source_path" ]; then
          ${pkgs.coreutils}/bin/rm \
            -f \
            -- \
            "$target_path"

          echo "[$display_name] Managed application link removed."
          return 0
        fi
      fi

    }

    ${managedDevelopmentApplicationLinkCommands}
  '';
in

{
  # ------------------------------------------------------------
  # ------ DEVELOPMENT PACKAGES ------ #
  # ------------------------------------------------------------

  environment.systemPackages = developmentPackages ++ enabledDevelopmentApplicationPackages;

  # ------------------------------------------------------------
  # ------ DEVELOPMENT APPLICATION LINKS ------ #
  # ------------------------------------------------------------

  system.activationScripts.postActivation.text = lib.mkAfter ''
    ${manageDevelopmentApplicationLinks}/bin/manage-darwin-development-application-links
  '';
}
