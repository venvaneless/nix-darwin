# darwin/system-commands/backups/helium.nix
# Helium browser backup command: `helium-backup`.

{ config, lib, pkgs, ... }:

let
  # ---- EDITABLE BACKUP PATHS
  destinationSegments = [ "helium" ];
  applicationSupportEntries = [
    { relativePath = "net.imput.helium"; destinationPath = "app-support/net.imput.helium"; }
  ];
  preferenceEntries = [
    { relativePath = "net.imput.helium.plist"; destinationPath = "app-pref/net.imput.helium.plist"; }
  ];
  additionalSources = [
    # { sourcePath = "/Users/ven/Library/Somewhere/Helium"; destinationPath = "additional/Helium"; }
  ];
  extraExcludePatterns = [ "sockets/" "private/socket" "*.sock" ];

  # ---- INDIVIDUAL AUTOMATIC BACKUP CONTROLS
  automatic = false;
  automaticIntervalSeconds = 86400;
  minimumIntervalSeconds = 28800;
  cpuLimitPercent = 25;
  archive = true;
  stageInDownloads = true;
  archiveFilenameTemplate = "{timestamp}-{prefix}.tar";
  archiveTimestampFormat = "%Y-%m-%d-%H%M%S";
  archivePrefix = "helium";
  preserveSymlinks = true;

  appBackupHelper = import ./app-backup-helper.nix { inherit lib pkgs; };
  heliumBackup = appBackupHelper.mkAppBackup {
    inherit config;
    appName = "Helium";
    appSlug = "helium";
    inherit automatic automaticIntervalSeconds minimumIntervalSeconds cpuLimitPercent;
    inherit archive stageInDownloads archiveFilenameTemplate archiveTimestampFormat archivePrefix preserveSymlinks;
    destinationRoot = "browserBackups";
    inherit destinationSegments applicationSupportEntries preferenceEntries additionalSources extraExcludePatterns;
  };
in
heliumBackup
