# shared/terminal/nvim/heirline.nix

# =====================================================================
# NEOVIM: HEIRLINE
#
# Dynamic Gruvbox statusline matching the WezTerm tabline palette
# =====================================================================

{ config, lib, ... }:

{
  config = lib.mkIf config.ven.features.terminal.nvim.enable {
    xdg.configFile."nvim/lua/plugins/heirline.lua".text = ''
      return {
        {
          "rebelot/heirline.nvim",

          opts = function(_, opts)
            local colors = {
              bg0 = "#282828",
              bg1 = "#3c3836",
              fg1 = "#ebdbb2",
              gray = "#a89984",
              yellow = "#fabd2f",
              orange = "#fe8019",
              aqua = "#83a598",
              green = "#b8bb26",
              red = "#fb4934",
            }

            local language_cache = {}

            local languages = {
              nix = { name = "Nix", icon = "" },
              lua = { name = "Lua", icon = "" },
              ts = { name = "TypeScript", icon = "" },
              tsx = { name = "TypeScript", icon = "" },
              js = { name = "JavaScript", icon = "" },
              jsx = { name = "JavaScript", icon = "" },
              py = { name = "Python", icon = "" },
              go = { name = "Go", icon = "" },
              rs = { name = "Rust", icon = "" },
              sh = { name = "Shell", icon = "" },
              bash = { name = "Shell", icon = "" },
              zsh = { name = "Shell", icon = "" },
              fish = { name = "Fish", icon = "󰈺" },
              html = { name = "HTML", icon = "" },
              css = { name = "CSS", icon = "" },
              scss = { name = "SCSS", icon = "" },
              vue = { name = "Vue", icon = "" },
              svelte = { name = "Svelte", icon = "" },
              md = { name = "Markdown", icon = "" },
            }

            local function project_root()
              local buffer = vim.api.nvim_get_current_buf()
              local filename = vim.api.nvim_buf_get_name(buffer)
              local start = filename ~= "" and vim.fs.dirname(filename) or vim.fn.getcwd()

              return vim.fs.root(start, {
                ".git",
                "flake.nix",
                "package.json",
                "Cargo.toml",
                "go.mod",
                "pyproject.toml",
              }) or vim.fn.getcwd()
            end

            -- Git worktree root for the current buffer. project_root()
            -- also matches flake.nix and friends, but Telescope's git
            -- pickers need an actual repository.
            local function git_root()
              local buffer = vim.api.nvim_get_current_buf()
              local filename = vim.api.nvim_buf_get_name(buffer)
              local start = filename ~= "" and vim.fs.dirname(filename) or vim.fn.getcwd()

              return vim.fs.root(start, ".git")
            end

            local function dominant_language()
              local root = project_root()

              if language_cache[root] then
                return language_cache[root]
              end

              local counts = {}
              local files = {}

              if vim.fn.executable("git") == 1 and vim.uv.fs_stat(root .. "/.git") then
                files = vim.fn.systemlist({
                  "git",
                  "-C",
                  root,
                  "ls-files",
                  "--cached",
                  "--others",
                  "--exclude-standard",
                })
              end

              for index, name in ipairs(files) do
                if index > 1500 then
                  break
                end

                local extension = name:match("%.([^./]+)$")

                if extension then
                  extension = extension:lower()

                  if languages[extension] then
                    counts[extension] = (counts[extension] or 0) + 1
                  end
                end
              end

              local winner
              local winner_count = 0

              for extension, count in pairs(counts) do
                if count > winner_count then
                  winner = extension
                  winner_count = count
                end
              end

              if not winner then
                local filetype = vim.bo.filetype
                local fallback = languages[filetype]

                language_cache[root] = fallback or {
                  name = filetype ~= "" and filetype or "Text",
                  icon = "󰈙",
                }

                return language_cache[root]
              end

              language_cache[root] = languages[winner]
              return language_cache[root]
            end

            local function segment(text, icon, foreground, background, next_background, click)
              local component = {
                {
                  provider = function()
                    local value = type(text) == "function" and text() or text
                    local glyph = type(icon) == "function" and icon() or icon

                    if not value or value == "" then
                      return ""
                    end

                    if glyph and glyph ~= "" then
                      return " " .. glyph .. " " .. value .. " "
                    end

                    return " " .. value .. " "
                  end,

                  hl = {
                    fg = foreground,
                    bg = background,
                    bold = true,
                  },
                },
              }

              if next_background then
                table.insert(component, {
                  provider = "",
                  hl = {
                    fg = background,
                    bg = next_background,
                  },
                })
              end

              if click then
                component.on_click = click
              end

              return component
            end

            local function reverse_segment(text, icon, foreground, background, previous_background, click)
              local component = {
                {
                  provider = "",
                  hl = {
                    fg = background,
                    bg = previous_background,
                  },
                },
                {
                  provider = function()
                    local value = type(text) == "function" and text() or text
                    local glyph = type(icon) == "function" and icon() or icon

                    if not value or value == "" then
                      return ""
                    end

                    if glyph and glyph ~= "" then
                      return " " .. glyph .. " " .. value .. " "
                    end

                    return " " .. value .. " "
                  end,

                  hl = {
                    fg = foreground,
                    bg = background,
                    bold = true,
                  },
                },
              }

              if click then
                component.on_click = click
              end

              return component
            end

            local user = segment(
              function() return vim.env.USER or vim.env.USERNAME or "user" end,
              "",
              colors.bg0,
              colors.yellow,
              colors.orange,
              {
                name = "heirline_user_click",
                callback = function()
                  local value = vim.env.USER or vim.env.USERNAME or ""
                  vim.fn.setreg("+", value)
                  vim.notify("Copied user: " .. value)
                end,
              }
            )

            local shell = segment(
              function()
                local shell_path = vim.env.SHELL or vim.o.shell or "shell"
                return vim.fs.basename(shell_path)
              end,
              function()
                local shell_path = vim.env.SHELL or vim.o.shell or "shell"
                local shell_name = vim.fs.basename(shell_path)

                return ({
                  fish = "󰈺",
                  zsh = "",
                  bash = "",
                })[shell_name] or ""
              end,
              colors.bg0,
              colors.orange,
              colors.aqua,
              {
                name = "heirline_shell_click",
                callback = function()
                  vim.cmd("botright split | terminal " .. vim.o.shell)
                end,
              }
            )

            local language = segment(
              function() return dominant_language().name end,
              function() return dominant_language().icon end,
              colors.bg0,
              colors.aqua,
              colors.green,
              {
                name = "heirline_language_click",
                callback = function()
                  language_cache[project_root()] = nil
                  vim.cmd("redrawstatus")
                end,
              }
            )

            -- Copilot registers a real LSP client, but it is a completion
            -- source rather than a language server, so it is hidden here.
            local ignored_lsp_clients = {
              copilot = true,
              ["copilot-language-server"] = true,
              ["GitHub Copilot"] = true,
            }

            local function attached_lsp_clients()
              local names = {}

              for _, client in ipairs(vim.lsp.get_clients({ bufnr = 0 })) do
                if not ignored_lsp_clients[client.name] then
                  table.insert(names, client.name)
                end
              end

              table.sort(names)

              return names
            end

            local lsp = segment(
              function()
                local names = attached_lsp_clients()

                if #names == 0 then
                  return "No LSP"
                end

                if #names == 1 then
                  return names[1]
                end

                return names[1] .. " +" .. (#names - 1)
              end,
              "",
              colors.bg0,
              colors.green,
              colors.bg1,
              {
                name = "heirline_lsp_click",
                callback = function()
                  local names = attached_lsp_clients()

                  -- Restart through nvim-lspconfig when its commands are
                  -- available, otherwise stop the client and let the
                  -- filetype autocommand attach it again.
                  local function restart(name)
                    if vim.fn.exists(":LspRestart") == 2 then
                      vim.cmd("LspRestart " .. name)
                      return
                    end

                    for _, client in ipairs(vim.lsp.get_clients({ name = name })) do
                      vim.lsp.stop_client(client.id, true)
                    end

                    vim.defer_fn(function()
                      vim.cmd("edit")
                    end, 500)
                  end

                  local function stop(name)
                    for _, client in ipairs(vim.lsp.get_clients({ name = name })) do
                      vim.lsp.stop_client(client.id, true)
                    end

                    vim.notify("Stopped LSP: " .. name)
                  end

                  local actions = {}

                  for _, name in ipairs(names) do
                    table.insert(actions, {
                      label = "Restart  " .. name,
                      run = function() restart(name) end,
                    })
                    table.insert(actions, {
                      label = "Stop     " .. name,
                      run = function() stop(name) end,
                    })
                  end

                  -- Always available, including when nothing is attached.
                  table.insert(actions, {
                    label = "Start / re-attach for this buffer",
                    run = function()
                      if vim.fn.exists(":LspStart") == 2 then
                        vim.cmd("LspStart")
                      else
                        vim.cmd("edit")
                      end
                    end,
                  })

                  table.insert(actions, {
                    label = "Restart all attached servers",
                    run = function()
                      for _, name in ipairs(names) do
                        restart(name)
                      end
                    end,
                  })

                  table.insert(actions, {
                    label = "LSP info",
                    run = function()
                      if vim.fn.exists(":LspInfo") == 2 then
                        vim.cmd("LspInfo")
                      else
                        vim.cmd("checkhealth vim.lsp")
                      end
                    end,
                  })

                  table.insert(actions, {
                    label = "LSP log",
                    run = function()
                      vim.cmd("tabnew " .. vim.lsp.get_log_path())
                    end,
                  })

                  local title = #names > 0 and ("LSP: " .. table.concat(names, ", "))
                    or "LSP: nothing attached"

                  vim.ui.select(actions, {
                    prompt = title,
                    format_item = function(action)
                      return action.label
                    end,
                  }, function(choice)
                    if choice then
                      choice.run()
                    end
                  end)
                end,
              }
            )

            lsp.update = {
              "LspAttach",
              "LspDetach",
              "BufEnter",
            }

            -- ---- GIT ---- #
            -- Repository name, branch, and per-buffer diff counts.
            -- Gitsigns publishes all of this in b:gitsigns_status_dict.
            local function git_status()
              return vim.b.gitsigns_status_dict
            end

            local function git_is_dirty()
              local status = git_status()

              if not status then
                return false
              end

              return ((status.added or 0) + (status.changed or 0) + (status.removed or 0)) > 0
            end

            -- Renders one diff counter, or nothing when the count is zero.
            local function diff_provider(key, prefix)
              return function()
                local status = git_status()
                local count = status and status[key] or 0

                if count == 0 then
                  return ""
                end

                return " " .. prefix .. count
              end
            end

            -- Keep the last saved file age beside the repository context,
            -- rather than spending room on every file in the Neo-tree sidebar.
            local function relative_file_mtime()
              local filename = vim.api.nvim_buf_get_name(0)

              if filename == "" or vim.bo.buftype ~= "" then
                return nil
              end

              if vim.bo.modified then
                return "unsaved"
              end

              local stat = vim.uv.fs_stat(filename)

              if not stat or not stat.mtime then
                return nil
              end

              local elapsed = math.max(0, os.time() - stat.mtime.sec)

              if elapsed < 60 then
                return "now"
              end

              if elapsed < 3600 then
                return math.floor(elapsed / 60) .. "m ago"
              end

              if elapsed < 86400 then
                return math.floor(elapsed / 3600) .. "h ago"
              end

              return math.floor(elapsed / 86400) .. "d ago"
            end

            local git = {
              -- Repository name, taken from the same root as the language segment.
              {
                provider = function()
                  return "  " .. vim.fs.basename(project_root()) .. " "
                end,

                hl = {
                  fg = colors.yellow,
                  bg = colors.bg1,
                  bold = true,
                },
              },

              -- Current branch; orange while the worktree has changes.
              {
                provider = function()
                  local status = git_status()

                  if not status or not status.head or status.head == "" then
                    return "no repo"
                  end

                  return " " .. status.head
                end,

                hl = function()
                  return {
                    fg = git_is_dirty() and colors.orange or colors.fg1,
                    bg = colors.bg1,
                    bold = true,
                  }
                end,
              },

              -- Added / changed / removed lines in this buffer.
              {
                provider = diff_provider("added", "+"),
                hl = {
                  fg = colors.green,
                  bg = colors.bg1,
                  bold = true,
                },
              },
              {
                provider = diff_provider("changed", "~"),
                hl = {
                  fg = colors.yellow,
                  bg = colors.bg1,
                  bold = true,
                },
              },
              {
                provider = diff_provider("removed", "-"),
                hl = {
                  fg = colors.red,
                  bg = colors.bg1,
                  bold = true,
                },
              },

              -- Current file's relative modification time.
              {
                provider = function()
                  local value = relative_file_mtime()

                  if not value then
                    return ""
                  end

                  return " 󰃭 " .. value
                end,

                hl = {
                  fg = colors.gray,
                  bg = colors.bg1,
                  bold = true,
                },
              },

              -- Trailing padding and the separator into the statusline body.
              {
                provider = " ",
                hl = {
                  bg = colors.bg1,
                },
              },
              {
                provider = "",
                hl = {
                  fg = colors.bg1,
                  bg = colors.bg0,
                },
              },

              on_click = {
                name = "heirline_git_click",
                callback = function()
                  local root = git_root()

                  -- Neovim's cwd is often the home directory, so every
                  -- picker below is scoped to the buffer's own repository.
                  if not root then
                    vim.notify(
                      "This buffer is not inside a Git repository",
                      vim.log.levels.WARN
                    )
                    return
                  end

                  local telescope = require("telescope.builtin")

                  local actions = {
                    {
                      label = "Switch branch",
                      run = function()
                        telescope.git_branches({ cwd = root })
                      end,
                    },
                    {
                      label = "Changed files",
                      run = function()
                        telescope.git_status({ cwd = root })
                      end,
                    },
                    {
                      label = "Commits",
                      run = function()
                        telescope.git_commits({ cwd = root })
                      end,
                    },
                    {
                      label = "Commits for this file",
                      run = function()
                        telescope.git_bcommits({ cwd = root })
                      end,
                    },
                    {
                      label = "Stashes",
                      run = function()
                        telescope.git_stash({ cwd = root })
                      end,
                    },
                  }

                  vim.ui.select(actions, {
                    prompt = vim.fs.basename(root) .. " — Git",
                    format_item = function(action)
                      return action.label
                    end,
                  }, function(choice)
                    if choice then
                      choice.run()
                    end
                  end)
                end,
              },

              update = {
                "BufEnter",
                "BufWritePost",
                "CursorHold",
                "FocusGained",
                "User",
              },
            }

            local fill = {
              provider = "%=",
              hl = {
                fg = colors.fg1,
                bg = colors.bg0,
              },
            }

            local host = reverse_segment(
              function() return vim.fn.hostname():gsub("%.local$", "") end,
              "󰒋",
              colors.bg0,
              colors.yellow,
              colors.bg0,
              {
                name = "heirline_host_click",
                callback = function()
                  local hostname = vim.fn.hostname():gsub("%.local$", "")
                  vim.fn.setreg("+", hostname)
                  vim.notify("Copied host: " .. hostname)
                end,
              }
            )

            local clock = reverse_segment(
              function() return os.date("%H:%M") end,
              "",
              colors.bg0,
              colors.orange,
              colors.yellow,
              {
                name = "heirline_clock_click",
                callback = function()
                  vim.notify(os.date("%A, %d %B %Y — %H:%M:%S"))
                end,
              }
            )

            clock.update = {
              "CursorHold",
              "CursorHoldI",
              "BufEnter",
            }

            opts.statusline = {
              hl = {
                fg = colors.fg1,
                bg = colors.bg0,
              },

              user,
              shell,
              language,
              lsp,
              git,
              fill,
              host,
              clock,
            }

            -- Dropbar owns the winbar; keep AstroNvim's existing tabline.
            opts.winbar = nil

            vim.opt.laststatus = 3
          end,
        },
      }
    '';
  };
}
