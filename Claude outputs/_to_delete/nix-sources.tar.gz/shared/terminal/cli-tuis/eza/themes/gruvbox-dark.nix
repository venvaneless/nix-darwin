# shared/terminal/cli-tuis/eza/themes/gruvbox-dark.nix
#
# =====================================================================
# EZA: GRUVBOX DARK THEME
#
# - Declares the Gruvbox Dark theme entirely in Nix
# - Selected directly in ../eza.nix with selectedTheme = "gruvboxDark"
# - Enabled only when eza.nix imports this theme module
#
# Home Manager renders this attribute set to
# $XDG_CONFIG_HOME/eza/theme.yml. Only one eza theme may be enabled.
#
# Converted from the eza-community/eza-themes collection
# =====================================================================

{ config, lib, ... }:

let
  ezaCfg = config.ven.features.terminal.cliTuis.eza;
  cfg = ezaCfg.themes.gruvboxDark;
in
{
  options.ven.features.terminal.cliTuis.eza.themes.gruvboxDark.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Gruvbox Dark theme selected in eza.nix.";
  };

  # Only applies when eza itself is enabled.
  config = lib.mkIf (ezaCfg.enable && cfg.enable) {
    programs.eza.theme = {
      colourful = true;
      filekinds = {
        normal = { foreground = "#ebdbb2"; };
        directory = { foreground = "#83a598"; };
        symlink = { foreground = "#8ec07c"; };
        pipe = { foreground = "#928374"; };
        block_device = { foreground = "#fb4934"; };
        char_device = { foreground = "#fb4934"; };
        socket = { foreground = "#665c54"; };
        special = { foreground = "#d3869b"; };
        executable = { foreground = "#b8bb26"; };
        mount_point = { foreground = "#fe8019"; };
      };
      perms = {
        user_read = { foreground = "#ebdbb2"; };
        user_write = { foreground = "#fabd2f"; };
        user_execute_file = { foreground = "#b8bb26"; };
        user_execute_other = { foreground = "#b8bb26"; };
        group_read = { foreground = "#ebdbb2"; };
        group_write = { foreground = "#fabd2f"; };
        group_execute = { foreground = "#b8bb26"; };
        other_read = { foreground = "#bdae93"; };
        other_write = { foreground = "#fabd2f"; };
        other_execute = { foreground = "#b8bb26"; };
        special_user_file = { foreground = "#d3869b"; };
        special_other = { foreground = "#928374"; };
        attribute = { foreground = "#bdae93"; };
      };
      size = {
        major = { foreground = "#bdae93"; };
        minor = { foreground = "#8ec07c"; };
        number_byte = { foreground = "#ebdbb2"; };
        number_kilo = { foreground = "#ebdbb2"; };
        number_mega = { foreground = "#83a598"; };
        number_giga = { foreground = "#d3869b"; };
        number_huge = { foreground = "#d3869b"; };
        unit_byte = { foreground = "#bdae93"; };
        unit_kilo = { foreground = "#83a598"; };
        unit_mega = { foreground = "#d3869b"; };
        unit_giga = { foreground = "#d3869b"; };
        unit_huge = { foreground = "#fe8019"; };
      };
      users = {
        user_you = { foreground = "#ebdbb2"; };
        user_root = { foreground = "#fb4934"; };
        user_other = { foreground = "#d3869b"; };
        group_yours = { foreground = "#ebdbb2"; };
        group_other = { foreground = "#928374"; };
        group_root = { foreground = "#fb4934"; };
      };
      links = {
        normal = { foreground = "#8ec07c"; };
        multi_link_file = { foreground = "#fe8019"; };
      };
      git = {
        new = { foreground = "#b8bb26"; };
        modified = { foreground = "#fabd2f"; };
        deleted = { foreground = "#fb4934"; };
        renamed = { foreground = "#8ec07c"; };
        typechange = { foreground = "#d3869b"; };
        ignored = { foreground = "#928374"; };
        conflicted = { foreground = "#cc241d"; };
      };
      git_repo = {
        branch_main = { foreground = "#ebdbb2"; };
        branch_other = { foreground = "#d3869b"; };
        git_clean = { foreground = "#b8bb26"; };
        git_dirty = { foreground = "#fb4934"; };
      };
      security_context = {
        colon = { foreground = "#928374"; };
        user = { foreground = "#ebdbb2"; };
        role = { foreground = "#d3869b"; };
        typ = { foreground = "#665c54"; };
        range = { foreground = "#d3869b"; };
      };
      file_type = {
        image = { foreground = "#fabd2f"; };
        video = { foreground = "#fb4934"; };
        music = { foreground = "#b8bb26"; };
        lossless = { foreground = "#8ec07c"; };
        crypto = { foreground = "#928374"; };
        document = { foreground = "#ebdbb2"; };
        compressed = { foreground = "#d3869b"; };
        temp = { foreground = "#cc241d"; };
        compiled = { foreground = "#83a598"; };
        build = { foreground = "#928374"; };
        source = { foreground = "#83a598"; };
      };
      punctuation = { foreground = "#928374"; };
      date = { foreground = "#fabd2f"; };
      inode = { foreground = "#bdae93"; };
      blocks = { foreground = "#a89984"; };
      header = { foreground = "#ebdbb2"; };
      octal = { foreground = "#8ec07c"; };
      flags = { foreground = "#d3869b"; };
      symlink_path = { foreground = "#8ec07c"; };
      control_char = { foreground = "#83a598"; };
      broken_symlink = { foreground = "#fb4934"; };
      broken_path_overlay = { foreground = "#928374"; };
    };
  };
}
