# shared/terminal/cli-tuis/eza/themes/tokyonight.nix
#
# =====================================================================
# EZA: TOKYO NIGHT THEME
#
# - Declares the Tokyo Night theme entirely in Nix
# - Toggle with ven.features.terminal.cliTuis.eza.themes.tokyonight.enable
# - Disabled by default; enable it after turning the active theme off
#
# Home Manager renders this attribute set to
# $XDG_CONFIG_HOME/eza/theme.yml. Only one eza theme may be enabled.
#
# Converted from the eza-community/eza-themes collection
# =====================================================================

{ config, lib, ... }:

let
  ezaCfg = config.ven.features.terminal.cliTuis.eza;
  cfg = ezaCfg.themes.tokyonight;
in
{
  options.ven.features.terminal.cliTuis.eza.themes.tokyonight.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Use the Tokyo Night theme for eza.";
  };

  # Only applies when eza itself is enabled.
  config = lib.mkIf (ezaCfg.enable && cfg.enable) {
    programs.eza.theme = {
      colourful = true;
      filekinds = {
        normal = { foreground = "#c0caf5"; };
        directory = { foreground = "#7aa2f7"; };
        symlink = { foreground = "#2ac3de"; };
        pipe = { foreground = "#414868"; };
        block_device = { foreground = "#e0af68"; };
        char_device = { foreground = "#e0af68"; };
        socket = { foreground = "#414868"; };
        special = { foreground = "#9d7cd8"; };
        executable = { foreground = "#9ece6a"; };
        mount_point = { foreground = "#b4f9f8"; };
      };
      perms = {
        user_read = { foreground = "#2ac3de"; };
        user_write = { foreground = "#bb9af7"; };
        user_execute_file = { foreground = "#9ece6a"; };
        user_execute_other = { foreground = "#9ece6a"; };
        group_read = { foreground = "#2ac3de"; };
        group_write = { foreground = "#ff9e64"; };
        group_execute = { foreground = "#9ece6a"; };
        other_read = { foreground = "#2ac3de"; };
        other_write = { foreground = "#ff007c"; };
        other_execute = { foreground = "#9ece6a"; };
        special_user_file = { foreground = "#ff007c"; };
        special_other = { foreground = "#db4b4b"; };
        attribute = { foreground = "#737aa2"; };
      };
      size = {
        major = { foreground = "#2ac3de"; };
        minor = { foreground = "#9d7cd8"; };
        number_byte = { foreground = "#a9b1d6"; };
        number_kilo = { foreground = "#89ddff"; };
        number_mega = { foreground = "#2ac3de"; };
        number_giga = { foreground = "#ff9e64"; };
        number_huge = { foreground = "#ff007c"; };
        unit_byte = { foreground = "#a9b1d6"; };
        unit_kilo = { foreground = "#89ddff"; };
        unit_mega = { foreground = "#2ac3de"; };
        unit_giga = { foreground = "#ff9e64"; };
        unit_huge = { foreground = "#ff007c"; };
      };
      users = {
        user_you = { foreground = "#3d59a1"; };
        user_root = { foreground = "#bb9af7"; };
        user_other = { foreground = "#2ac3de"; };
        group_yours = { foreground = "#89ddff"; };
        group_root = { foreground = "#bb9af7"; };
        group_other = { foreground = "#c0caf5"; };
      };
      links = {
        normal = { foreground = "#89ddff"; };
        multi_link_file = { foreground = "#2ac3de"; };
      };
      git = {
        new = { foreground = "#9ece6a"; };
        modified = { foreground = "#bb9af7"; };
        deleted = { foreground = "#db4b4b"; };
        renamed = { foreground = "#2ac3de"; };
        typechange = { foreground = "#2ac3de"; };
        ignored = { foreground = "#545c7e"; };
        conflicted = { foreground = "#ff9e64"; };
      };
      git_repo = {
        branch_main = { foreground = "#737aa2"; };
        branch_other = { foreground = "#b4f9f8"; };
        git_clean = { foreground = "#292e42"; };
        git_dirty = { foreground = "#bb9af7"; };
      };
      security_context = {
        colon = { foreground = "#545c7e"; };
        user = { foreground = "#737aa2"; };
        role = { foreground = "#2ac3de"; };
        typ = { foreground = "#3d59a1"; };
        range = { foreground = "#9d7cd8"; };
      };
      file_type = {
        image = { foreground = "#89ddff"; };
        video = { foreground = "#b4f9f8"; };
        music = { foreground = "#73daca"; };
        lossless = { foreground = "#41a6b5"; };
        crypto = { foreground = "#db4b4b"; };
        document = { foreground = "#a9b1d6"; };
        compressed = { foreground = "#ff9e64"; };
        temp = { foreground = "#737aa2"; };
        compiled = { foreground = "#737aa2"; };
        build = { foreground = "#1abc9c"; };
        source = { foreground = "#bb9af7"; };
      };
      punctuation = { foreground = "#414868"; };
      date = { foreground = "#e0af68"; };
      inode = { foreground = "#737aa2"; };
      blocks = { foreground = "#737aa2"; };
      header = { foreground = "#a9b1d6"; };
      octal = { foreground = "#ff9e64"; };
      flags = { foreground = "#9d7cd8"; };
      symlink_path = { foreground = "#89ddff"; };
      control_char = { foreground = "#ff9e64"; };
      broken_symlink = { foreground = "#ff007c"; };
      broken_path_overlay = { foreground = "#ff007c"; };
    };
  };
}
