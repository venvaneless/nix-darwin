# shared/terminal/cli-tuis/eza/themes/rose-pine.nix
#
# =====================================================================
# EZA: ROSÉ PINE THEME
#
# - Declares the Rosé Pine theme entirely in Nix
# - Toggle with ven.features.terminal.cliTuis.eza.themes.rosePine.enable
# - Disabled by default; enable it after turning the active theme off
#
# Home Manager renders this attribute set to
# $XDG_CONFIG_HOME/eza/theme.yml. Only one eza theme may be enabled.
#
# Converted from the eza-community/eza-themes collection
# =====================================================================

{ config, lib, ... }:

let
  ezaCfg = config.ven.features.terminal.cliTuis.eza;
  cfg = ezaCfg.themes.rosePine;
in
{
  options.ven.features.terminal.cliTuis.eza.themes.rosePine.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Use the Rosé Pine theme for eza.";
  };

  # Only applies when eza itself is enabled.
  config = lib.mkIf (ezaCfg.enable && cfg.enable) {
    programs.eza.theme = {
      colourful = true;
      filekinds = {
        normal = { foreground = "#e0def4"; };
        directory = { foreground = "#9ccfd8"; };
        symlink = { foreground = "#524f67"; };
        pipe = { foreground = "#908caa"; };
        block_device = { foreground = "#ebbcba"; };
        char_device = { foreground = "#f6c177"; };
        socket = { foreground = "#21202e"; };
        special = { foreground = "#c4a7e7"; };
        executable = { foreground = "#c4a7e7"; };
        mount_point = { foreground = "#403d52"; };
      };
      perms = {
        user_read = { foreground = "#908caa"; };
        user_write = { foreground = "#403d52"; };
        user_execute_file = { foreground = "#c4a7e7"; };
        user_execute_other = { foreground = "#c4a7e7"; };
        group_read = { foreground = "#908caa"; };
        group_write = { foreground = "#403d52"; };
        group_execute = { foreground = "#c4a7e7"; };
        other_read = { foreground = "#908caa"; };
        other_write = { foreground = "#403d52"; };
        other_execute = { foreground = "#c4a7e7"; };
        special_user_file = { foreground = "#c4a7e7"; };
        special_other = { foreground = "#403d52"; };
        attribute = { foreground = "#908caa"; };
      };
      size = {
        major = { foreground = "#908caa"; };
        minor = { foreground = "#9ccfd8"; };
        number_byte = { foreground = "#908caa"; };
        number_kilo = { foreground = "#524f67"; };
        number_mega = { foreground = "#31748f"; };
        number_giga = { foreground = "#c4a7e7"; };
        number_huge = { foreground = "#c4a7e7"; };
        unit_byte = { foreground = "#908caa"; };
        unit_kilo = { foreground = "#31748f"; };
        unit_mega = { foreground = "#c4a7e7"; };
        unit_giga = { foreground = "#c4a7e7"; };
        unit_huge = { foreground = "#9ccfd8"; };
      };
      users = {
        user_you = { foreground = "#f6c177"; };
        user_root = { foreground = "#eb6f92"; };
        user_other = { foreground = "#c4a7e7"; };
        group_yours = { foreground = "#524f67"; };
        group_other = { foreground = "#6e6a86"; };
        group_root = { foreground = "#eb6f92"; };
      };
      links = {
        normal = { foreground = "#9ccfd8"; };
        multi_link_file = { foreground = "#31748f"; };
      };
      git = {
        new = { foreground = "#9ccfd8"; };
        modified = { foreground = "#f6c177"; };
        deleted = { foreground = "#eb6f92"; };
        renamed = { foreground = "#31748f"; };
        typechange = { foreground = "#c4a7e7"; };
        ignored = { foreground = "#6e6a86"; };
        conflicted = { foreground = "#ebbcba"; };
      };
      git_repo = {
        branch_main = { foreground = "#908caa"; };
        branch_other = { foreground = "#c4a7e7"; };
        git_clean = { foreground = "#9ccfd8"; };
        git_dirty = { foreground = "#eb6f92"; };
      };
      security_context = {
        colon = { foreground = "#908caa"; };
        user = { foreground = "#9ccfd8"; };
        role = { foreground = "#c4a7e7"; };
        typ = { foreground = "#6e6a86"; };
        range = { foreground = "#c4a7e7"; };
      };
      file_type = {
        image = { foreground = "#f6c177"; };
        video = { foreground = "#eb6f92"; };
        music = { foreground = "#9ccfd8"; };
        lossless = { foreground = "#6e6a86"; };
        crypto = { foreground = "#403d52"; };
        document = { foreground = "#908caa"; };
        compressed = { foreground = "#c4a7e7"; };
        temp = { foreground = "#ebbcba"; };
        compiled = { foreground = "#31748f"; };
        build = { foreground = "#6e6a86"; };
        source = { foreground = "#ebbcba"; };
      };
      punctuation = { foreground = "#524f67"; };
      date = { foreground = "#31748f"; };
      inode = { foreground = "#908caa"; };
      blocks = { foreground = "#6e6a86"; };
      header = { foreground = "#908caa"; };
      octal = { foreground = "#9ccfd8"; };
      flags = { foreground = "#c4a7e7"; };
      symlink_path = { foreground = "#9ccfd8"; };
      control_char = { foreground = "#31748f"; };
      broken_symlink = { foreground = "#eb6f92"; };
      broken_path_overlay = { foreground = "#524f67"; };
    };
  };
}
