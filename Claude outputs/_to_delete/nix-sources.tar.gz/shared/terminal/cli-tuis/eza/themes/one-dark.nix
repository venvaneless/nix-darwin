# shared/terminal/cli-tuis/eza/themes/one-dark.nix
#
# =====================================================================
# EZA: ONE DARK THEME
#
# - Declares the One Dark theme entirely in Nix
# - Toggle with ven.features.terminal.cliTuis.eza.themes.oneDark.enable
# - Disabled by default; enable it after turning the active theme off
#
# Home Manager renders this attribute set to
# $XDG_CONFIG_HOME/eza/theme.yml. Only one eza theme may be enabled.
#
# Converted from the eza-community/eza-themes collection
# =====================================================================

{ config, lib, ... }:

let
  ezaCfg = config.ven.features.terminal.cliTuis.eza;
  cfg = ezaCfg.themes.oneDark;
in
{
  options.ven.features.terminal.cliTuis.eza.themes.oneDark.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Use the One Dark theme for eza.";
  };

  # Only applies when eza itself is enabled.
  config = lib.mkIf (ezaCfg.enable && cfg.enable) {
    programs.eza.theme = {
      colourful = true;
      filekinds = {
        normal = { foreground = "#ABB2BF"; };
        directory = { foreground = "#61AFEF"; };
        symlink = { foreground = "#56B6C2"; };
        pipe = { foreground = "#5C6370"; };
        block_device = { foreground = "#E5C07B"; };
        char_device = { foreground = "#E5C07B"; };
        socket = { foreground = "#5C6370"; };
        special = { foreground = "#C678DD"; };
        executable = { foreground = "#98C379"; };
        mount_point = { foreground = "#61AFEF"; };
      };
      perms = {
        user_read = { foreground = "#ABB2BF"; };
        user_write = { foreground = "#D19A66"; };
        user_execute_file = { foreground = "#98C379"; };
        user_execute_other = { foreground = "#98C379"; };
        group_read = { foreground = "#ABB2BF"; };
        group_write = { foreground = "#D19A66"; };
        group_execute = { foreground = "#98C379"; };
        other_read = { foreground = "#5C6370"; };
        other_write = { foreground = "#D19A66"; };
        other_execute = { foreground = "#98C379"; };
        special_user_file = { foreground = "#C678DD"; };
        special_other = { foreground = "#5C6370"; };
        attribute = { foreground = "#5C6370"; };
      };
      size = {
        major = { foreground = "#5C6370"; };
        minor = { foreground = "#56B6C2"; };
        number_byte = { foreground = "#ABB2BF"; };
        number_kilo = { foreground = "#ABB2BF"; };
        number_mega = { foreground = "#61AFEF"; };
        number_giga = { foreground = "#C678DD"; };
        number_huge = { foreground = "#C678DD"; };
        unit_byte = { foreground = "#5C6370"; };
        unit_kilo = { foreground = "#61AFEF"; };
        unit_mega = { foreground = "#C678DD"; };
        unit_giga = { foreground = "#C678DD"; };
        unit_huge = { foreground = "#61AFEF"; };
      };
      users = {
        user_you = { foreground = "#ABB2BF"; };
        user_root = { foreground = "#E06C75"; };
        user_other = { foreground = "#C678DD"; };
        group_yours = { foreground = "#ABB2BF"; };
        group_other = { foreground = "#5C6370"; };
        group_root = { foreground = "#E06C75"; };
      };
      links = {
        normal = { foreground = "#56B6C2"; };
        multi_link_file = { foreground = "#61AFEF"; };
      };
      git = {
        new = { foreground = "#98C379"; };
        modified = { foreground = "#E5C07B"; };
        deleted = { foreground = "#E06C75"; };
        renamed = { foreground = "#98C379"; };
        typechange = { foreground = "#C678DD"; };
        ignored = { foreground = "#5C6370"; };
        conflicted = { foreground = "#E06C75"; };
      };
      git_repo = {
        branch_main = { foreground = "#ABB2BF"; };
        branch_other = { foreground = "#C678DD"; };
        git_clean = { foreground = "#98C379"; };
        git_dirty = { foreground = "#E06C75"; };
      };
      security_context = {
        colon = { foreground = "#5C6370"; };
        user = { foreground = "#ABB2BF"; };
        role = { foreground = "#C678DD"; };
        typ = { foreground = "#5C6370"; };
        range = { foreground = "#C678DD"; };
      };
      file_type = {
        image = { foreground = "#E5C07B"; };
        video = { foreground = "#E06C75"; };
        music = { foreground = "#98C379"; };
        lossless = { foreground = "#56B6C2"; };
        crypto = { foreground = "#5C6370"; };
        document = { foreground = "#ABB2BF"; };
        compressed = { foreground = "#C678DD"; };
        temp = { foreground = "#E06C75"; };
        compiled = { foreground = "#61AFEF"; };
        build = { foreground = "#5C6370"; };
        source = { foreground = "#61AFEF"; };
      };
      punctuation = { foreground = "#5C6370"; };
      date = { foreground = "#E5C07B"; };
      inode = { foreground = "#5C6370"; };
      blocks = { foreground = "#5C6370"; };
      header = { foreground = "#ABB2BF"; };
      octal = { foreground = "#56B6C2"; };
      flags = { foreground = "#C678DD"; };
      symlink_path = { foreground = "#56B6C2"; };
      control_char = { foreground = "#61AFEF"; };
      broken_symlink = { foreground = "#E06C75"; };
      broken_path_overlay = { foreground = "#5C6370"; };
    };
  };
}
