# shared/terminal/cli-tuis/eza/themes/solarized-dark.nix
#
# =====================================================================
# EZA: SOLARIZED DARK THEME
#
# - Declares the Solarized Dark theme entirely in Nix
# - Toggle with ven.features.terminal.cliTuis.eza.themes.solarizedDark.enable
# - Disabled by default; enable it after turning the active theme off
#
# Home Manager renders this attribute set to
# $XDG_CONFIG_HOME/eza/theme.yml. Only one eza theme may be enabled.
#
# Converted from the eza-community/eza-themes collection
# =====================================================================

{ config, lib, ... }:

let
  ezaCfg = config.ven.features.terminal.cliTuis.eza;
  cfg = ezaCfg.themes.solarizedDark;
in
{
  options.ven.features.terminal.cliTuis.eza.themes.solarizedDark.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Use the Solarized Dark theme for eza.";
  };

  # Only applies when eza itself is enabled.
  config = lib.mkIf (ezaCfg.enable && cfg.enable) {
    programs.eza.theme = {
      colourful = true;
      filekinds = {
        normal = { foreground = "#839496"; };
        directory = {
          foreground = "#268bd2";
          is_bold = true;
        };
        symlink = { foreground = "#2aa198"; };
        pipe = { foreground = "#657b83"; };
        block_device = { foreground = "#dc322f"; };
        char_device = { foreground = "#dc322f"; };
        socket = { foreground = "#6c71c4"; };
        special = { foreground = "#d33682"; };
        executable = {
          foreground = "#859900";
          is_bold = true;
        };
        mount_point = { foreground = "#cb4b16"; };
      };
      perms = {
        user_read = { foreground = "#839496"; };
        user_write = { foreground = "#b58900"; };
        user_execute_file = { foreground = "#859900"; };
        user_execute_other = { foreground = "#859900"; };
        group_read = { foreground = "#839496"; };
        group_write = { foreground = "#b58900"; };
        group_execute = { foreground = "#859900"; };
        other_read = { foreground = "#93a1a1"; };
        other_write = { foreground = "#b58900"; };
        other_execute = { foreground = "#859900"; };
        special_user_file = { foreground = "#d33682"; };
        special_other = { foreground = "#657b83"; };
        attribute = { foreground = "#93a1a1"; };
      };
      size = {
        major = { foreground = "#93a1a1"; };
        minor = { foreground = "#2aa198"; };
        number_byte = { foreground = "#839496"; };
        number_kilo = { foreground = "#839496"; };
        number_mega = { foreground = "#268bd2"; };
        number_giga = { foreground = "#d33682"; };
        number_huge = { foreground = "#dc322f"; };
        unit_byte = { foreground = "#93a1a1"; };
        unit_kilo = { foreground = "#268bd2"; };
        unit_mega = { foreground = "#d33682"; };
        unit_giga = { foreground = "#d33682"; };
        unit_huge = { foreground = "#dc322f"; };
      };
      users = {
        user_you = { foreground = "#839496"; };
        user_root = {
          foreground = "#dc322f";
          is_bold = true;
        };
        user_other = { foreground = "#d33682"; };
        group_yours = { foreground = "#839496"; };
        group_other = { foreground = "#657b83"; };
        group_root = { foreground = "#dc322f"; };
      };
      links = {
        normal = { foreground = "#2aa198"; };
        multi_link_file = { foreground = "#cb4b16"; };
      };
      git = {
        new = { foreground = "#859900"; };
        modified = { foreground = "#b58900"; };
        deleted = { foreground = "#dc322f"; };
        renamed = { foreground = "#2aa198"; };
        typechange = { foreground = "#d33682"; };
        ignored = { foreground = "#657b83"; };
        conflicted = {
          foreground = "#dc322f";
          is_bold = true;
        };
      };
      git_repo = {
        branch_main = { foreground = "#839496"; };
        branch_other = { foreground = "#d33682"; };
        git_clean = { foreground = "#859900"; };
        git_dirty = { foreground = "#dc322f"; };
      };
      security_context = {
        colon = { foreground = "#657b83"; };
        user = { foreground = "#839496"; };
        role = { foreground = "#d33682"; };
        typ = { foreground = "#586e75"; };
        range = { foreground = "#d33682"; };
      };
      file_type = {
        image = { foreground = "#d33682"; };
        video = { foreground = "#dc322f"; };
        music = { foreground = "#859900"; };
        lossless = { foreground = "#2aa198"; };
        crypto = { foreground = "#6c71c4"; };
        document = { foreground = "#268bd2"; };
        compressed = { foreground = "#b58900"; };
        temp = { foreground = "#dc322f"; };
        compiled = { foreground = "#268bd2"; };
        build = { foreground = "#657b83"; };
        source = { foreground = "#268bd2"; };
      };
      punctuation = { foreground = "#657b83"; };
      date = { foreground = "#b58900"; };
      inode = { foreground = "#93a1a1"; };
      blocks = { foreground = "#93a1a1"; };
      header = { foreground = "#839496"; };
      octal = { foreground = "#2aa198"; };
      flags = { foreground = "#d33682"; };
      symlink_path = { foreground = "#2aa198"; };
      control_char = { foreground = "#268bd2"; };
      broken_symlink = { foreground = "#dc322f"; };
      broken_path_overlay = { foreground = "#657b83"; };
    };
  };
}
