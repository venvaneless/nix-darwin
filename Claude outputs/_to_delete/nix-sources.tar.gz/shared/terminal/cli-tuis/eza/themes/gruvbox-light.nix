# shared/terminal/cli-tuis/eza/themes/gruvbox-light.nix
#
# =====================================================================
# EZA: GRUVBOX LIGHT THEME
#
# - Declares the Gruvbox Light theme entirely in Nix
# - Toggle with ven.features.terminal.cliTuis.eza.themes.gruvboxLight.enable
# - Disabled by default; enable it after turning the active theme off
#
# Home Manager renders this attribute set to
# $XDG_CONFIG_HOME/eza/theme.yml. Only one eza theme may be enabled.
#
# Converted from the eza-community/eza-themes collection
# =====================================================================

{ config, lib, ... }:

let
  ezaCfg = config.ven.features.terminal.cliTuis.eza;
  cfg = ezaCfg.themes.gruvboxLight;
in
{
  options.ven.features.terminal.cliTuis.eza.themes.gruvboxLight.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Use the Gruvbox Light theme for eza.";
  };

  # Only applies when eza itself is enabled.
  config = lib.mkIf (ezaCfg.enable && cfg.enable) {
    programs.eza.theme = {
      colourful = true;
      filekinds = {
        normal = { foreground = "#3c3836"; };
        directory = { foreground = "#076678"; };
        symlink = { foreground = "#427b58"; };
        pipe = { foreground = "#7c6f64"; };
        block_device = { foreground = "#9d0006"; };
        char_device = { foreground = "#9d0006"; };
        socket = { foreground = "#a89984"; };
        special = { foreground = "#b16286"; };
        executable = { foreground = "#98971a"; };
        mount_point = { foreground = "#d65d0e"; };
      };
      perms = {
        user_read = { foreground = "#3c3836"; };
        user_write = { foreground = "#d79921"; };
        user_execute_file = { foreground = "#98971a"; };
        user_execute_other = { foreground = "#98971a"; };
        group_read = { foreground = "#3c3836"; };
        group_write = { foreground = "#d79921"; };
        group_execute = { foreground = "#98971a"; };
        other_read = { foreground = "#7c6f64"; };
        other_write = { foreground = "#d79921"; };
        other_execute = { foreground = "#98971a"; };
        special_user_file = { foreground = "#b16286"; };
        special_other = { foreground = "#7c6f64"; };
        attribute = { foreground = "#7c6f64"; };
      };
      size = {
        major = { foreground = "#7c6f64"; };
        minor = { foreground = "#427b58"; };
        number_byte = { foreground = "#3c3836"; };
        number_kilo = { foreground = "#3c3836"; };
        number_mega = { foreground = "#076678"; };
        number_giga = { foreground = "#b16286"; };
        number_huge = { foreground = "#b16286"; };
        unit_byte = { foreground = "#7c6f64"; };
        unit_kilo = { foreground = "#076678"; };
        unit_mega = { foreground = "#b16286"; };
        unit_giga = { foreground = "#b16286"; };
        unit_huge = { foreground = "#d65d0e"; };
      };
      users = {
        user_you = { foreground = "#3c3836"; };
        user_root = { foreground = "#9d0006"; };
        user_other = { foreground = "#b16286"; };
        group_yours = { foreground = "#3c3836"; };
        group_other = { foreground = "#7c6f64"; };
        group_root = { foreground = "#9d0006"; };
      };
      links = {
        normal = { foreground = "#427b58"; };
        multi_link_file = { foreground = "#d65d0e"; };
      };
      git = {
        new = { foreground = "#98971a"; };
        modified = { foreground = "#d79921"; };
        deleted = { foreground = "#9d0006"; };
        renamed = { foreground = "#427b58"; };
        typechange = { foreground = "#b16286"; };
        ignored = { foreground = "#7c6f64"; };
        conflicted = { foreground = "#cc241d"; };
      };
      git_repo = {
        branch_main = { foreground = "#3c3836"; };
        branch_other = { foreground = "#b16286"; };
        git_clean = { foreground = "#98971a"; };
        git_dirty = { foreground = "#9d0006"; };
      };
      security_context = {
        colon = { foreground = "#7c6f64"; };
        user = { foreground = "#3c3836"; };
        role = { foreground = "#b16286"; };
        typ = { foreground = "#a89984"; };
        range = { foreground = "#b16286"; };
      };
      file_type = {
        image = { foreground = "#d79921"; };
        video = { foreground = "#9d0006"; };
        music = { foreground = "#98971a"; };
        lossless = { foreground = "#427b58"; };
        crypto = { foreground = "#7c6f64"; };
        document = { foreground = "#3c3836"; };
        compressed = { foreground = "#b16286"; };
        temp = { foreground = "#cc241d"; };
        compiled = { foreground = "#076678"; };
        build = { foreground = "#7c6f64"; };
        source = { foreground = "#076678"; };
      };
      punctuation = { foreground = "#7c6f64"; };
      date = { foreground = "#d79921"; };
      inode = { foreground = "#7c6f64"; };
      blocks = { foreground = "#928374"; };
      header = { foreground = "#3c3836"; };
      octal = { foreground = "#427b58"; };
      flags = { foreground = "#b16286"; };
      symlink_path = { foreground = "#427b58"; };
      control_char = { foreground = "#076678"; };
      broken_symlink = { foreground = "#9d0006"; };
      broken_path_overlay = { foreground = "#7c6f64"; };
    };
  };
}
