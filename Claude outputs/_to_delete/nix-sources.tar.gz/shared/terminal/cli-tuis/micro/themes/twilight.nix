# shared/terminal/cli-tuis/micro/themes/twilight.nix
#
# =====================================================================
# MICRO: TWILIGHT THEME
#
# - Twilight theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "twilight"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.twilight;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.twilight.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Twilight theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/twilight.micro".text = ''
      # Twilight color scheme
      color-link default "#F8F8F8,#141414"
      color-link color-column "#1B1B1B"
      color-link comment "#5F5A60"
      color-link constant "#CF6A4C"
      #color-link constant.number "#CF6A4C"
      color-link constant.specialChar "#DDF2A4"
      color-link constant.string "#8F9D6A"
      color-link current-line-number "#868686,#1B1B1B"
      color-link cursor-line "#1B1B1B"
      color-link divider "#1E1E1E"
      color-link error "#D2A8A1"
      color-link diff-added "#00AF00"
      color-link diff-modified "#FFAF00"
      color-link diff-deleted "#D70000"
      color-link gutter-error "#9B859D"
      color-link gutter-warning "#9B859D"
      color-link hlsearch "#141414,#C0C000"
      color-link identifier "#9B703F"
      color-link identifier.class "#DAD085"
      color-link identifier.var "#7587A6"
      color-link indent-char "#515151"
      color-link line-number "#868686,#1B1B1B"
      color-link current-line-number "#868686,#141414"
      color-link preproc "#E0C589"
      color-link special "#E0C589"
      color-link statement "#CDA869"
      color-link statusline "#515151,#1E1E1E"
      color-link symbol "#AC885B"
      color-link symbol.brackets "#F8F8F8"
      color-link symbol.operator "#CDA869"
      color-link symbol.tag "#AC885B"
      color-link tabbar "#F2F0EC,#2D2D2D"
      color-link todo "#8B98AB"
      color-link type "#F9EE98"
      color-link type.keyword "#CDA869"
      color-link underlined "#8996A8"
    '';
  };
}
