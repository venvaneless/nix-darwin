# shared/terminal/cli-tuis/micro/themes/material-tc.nix
#
# =====================================================================
# MICRO: MATERIAL TC THEME
#
# - Material TC theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "material-tc"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.material-tc;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.material-tc.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Material TC theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/material-tc.micro".text = ''
      color-link color-column "#263238"
      color-link comment "#4F6875,#263238"
      color-link constant "#F07178,#263238"
      color-link constant.number "#F78C6A,#263238"
      color-link constant.specialChar "#89DDF3,#263238"
      color-link constant.string "#C3E88D,#263238"
      color-link current-line-number "#80DEEA,#263238"
      color-link cursor-line "#283942"
      color-link default "#EEFFFF,#263238"
      color-link diff-added "#00AF00"
      color-link diff-modified "#FFAF00"
      color-link diff-deleted "#D70000"
      color-link divider "#263238,#80DEEA"
      color-link error "bold #263238,#F07178"
      color-link gutter-error "#EEFFFF,#F07178"
      color-link gutter-warning "#EEFFFF,#FFF176"
      color-link hlsearch "#FFFFFF,#546E7A"
      color-link identifier "#82AAFF,#263238"
      color-link identifier.macro "#FFCB6B,#263238"
      color-link indent-char "#505050,#263238"
      color-link line-number "#656866,#283942"
      color-link preproc "#C792EA,#263238"
      color-link special "#C792EA,#263238"
      color-link statement "#C792EA,#263238"
      color-link statusline "#80DEEA,#3b4d56"
      color-link symbol "#96CBFE,#263238"
      color-link symbol.brackets "#89DDF3,#263238"
      color-link symbol.operator "#C792EA,#263238"
      color-link tabbar "#80DEEA,#3b4d56"
      color-link todo "bold #C792EA,#263238"
      color-link type "#FFCB6B,#263238"
      color-link underlined "underline #EEFFFF,#263238"
    '';
  };
}
