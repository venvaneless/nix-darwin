# shared/terminal/cli-tuis/micro/themes/monokai.nix
#
# =====================================================================
# MICRO: MONOKAI THEME
#
# - Monokai theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "monokai"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.monokai;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.monokai.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Monokai theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/monokai.micro".text = ''
      color-link default "#F8F8F2,#282828"
      color-link comment "#75715E,#282828"
      color-link identifier "#66D9EF,#282828"
      color-link constant "#AE81FF,#282828"
      color-link constant.string "#E6DB74,#282828"
      color-link constant.string.char "#BDE6AD,#282828"
      color-link statement "#F92672,#282828"
      color-link symbol.operator "#F92672,#282828"
      color-link preproc "#CB4B16,#282828"
      color-link type "#66D9EF,#282828"
      color-link special "#A6E22E,#282828"
      color-link underlined "#D33682,#282828"
      color-link error "bold #CB4B16,#282828"
      color-link todo "bold #D33682,#282828"
      color-link hlsearch "#282828,#E6DB74"
      color-link statusline "#282828,#F8F8F2"
      color-link tabbar "#282828,#F8F8F2"
      color-link indent-char "#505050,#282828"
      color-link line-number "#AAAAAA,#323232"
      color-link current-line-number "#AAAAAA,#282828"
      color-link diff-added "#00AF00"
      color-link diff-modified "#FFAF00"
      color-link diff-deleted "#D70000"
      color-link gutter-error "#CB4B16,#282828"
      color-link gutter-warning "#E6DB74,#282828"
      color-link cursor-line "#323232"
      color-link color-column "#323232"
      #No extended types; Plain brackets.
      color-link type.extended "default"
      #color-link symbol.brackets "default"
      color-link symbol.tag "#AE81FF,#282828"
    '';
  };
}
