# shared/terminal/cli-tuis/micro/themes/zenburn.nix
#
# =====================================================================
# MICRO: ZENBURN THEME
#
# - Zenburn theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "zenburn"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.zenburn;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.zenburn.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Zenburn theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/zenburn.micro".text = ''
      color-link default "188,237"
      color-link comment "108,237"
      color-link constant.string "174,237"
      color-link constant.number "116,237"
      color-link constant "181,237"
      color-link identifier "223,237"
      color-link statement "223,237"
      color-link symbol "223,237"
      color-link preproc "223,237"
      color-link type "187,237"
      color-link special "181,237"
      color-link underlined "188,237"
      color-link error "115,236"
      color-link todo "bold 254,237"
      color-link hlsearch "230,22"
      color-link statusline "186,236"
      color-link tabbar "186,236"
      color-link indent-char "238,237"
      color-link line-number "248,238"
      color-link diff-added "34"
      color-link diff-modified "214"
      color-link diff-deleted "160"
      color-link gutter-error "237,174"
      color-link gutter-warning "174,237"
      color-link cursor-line "238"
      color-link color-column "238"
      color-link current-line-number "188,237"
    '';
  };
}
