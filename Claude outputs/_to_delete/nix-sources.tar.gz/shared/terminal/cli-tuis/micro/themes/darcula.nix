# shared/terminal/cli-tuis/micro/themes/darcula.nix
#
# =====================================================================
# MICRO: DARCULA THEME
#
# - Official Darcula theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "darcula"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.darcula;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.darcula.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Darcula theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/darcula.micro".text = ''
      color-link default "#CCCCCC,#242424"
      color-link comment "#707070,#242424"
      color-link identifier "#FFC66D,#242424"
      color-link constant "#7A9EC2,#242424"
      color-link constant.string "#6A8759,#242424"
      color-link constant.string.char "#6A8759,#242424"
      color-link statement "#CC8242,#242424"
      color-link symbol "#CCCCCC,#242424"
      color-link preproc "#CC8242,#242424"
      color-link type "#CC8242,#242424"
      color-link special "#CC8242,#242424"
      color-link underlined "#D33682,#242424"
      color-link error "bold #CB4B16,#242424"
      color-link todo "bold #D33682,#242424"
      color-link hlsearch "#CCCCCC,#32593D"
      color-link statusline "#242424,#CCCCCC"
      color-link tabbar "#242424,#CCCCCC"
      color-link indent-char "#4F4F4F,#242424"
      color-link line-number "#666666,#2C2C2C"
      color-link current-line-number "#666666,#242424"
      color-link diff-added "#00AF00"
      color-link diff-modified "#FFAF00"
      color-link diff-deleted "#D70000"
      color-link gutter-error "#CB4B16,#242424"
      color-link gutter-warning "#E6DB74,#242424"
      color-link cursor-line "#2C2C2C"
      color-link color-column "#2C2C2C"
      #No extended types; Plain brackets.
      color-link type.extended "default"
      #color-link symbol.brackets "default"
      color-link symbol.tag "#AE81FF,#242424"
    '';
  };
}
