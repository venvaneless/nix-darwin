# shared/terminal/cli-tuis/micro/themes/dukedark-tc.nix
#
# =====================================================================
# MICRO: DUKEDARK TC THEME
#
# - Dukedark TC theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "dukedark-tc"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.dukedark-tc;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.dukedark-tc.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Dukedark TC theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/dukedark-tc.micro".text = ''
      color-link color-column "#001e28"
      color-link comment "#608b4e,#001e28"
      color-link constant.bool "#fd971f,#001e28"
      color-link constant "#fd971f,#001e28"
      color-link constant.string "#a0f000,#001e28"
      color-link constant.string.char "#a0f000,#001e28"
      color-link constant.string.url "#a0f000,#001e28"
      color-link current-line-number "bold #fd971f,#001e28"
      color-link cursor-line "#001923"
      color-link default "#ffffff,#001e28"
      color-link diff-added "#00c8a0,#001e28"
      color-link diff-modified "#fd971f,#001e28"
      color-link diff-deleted "#cb4b16,#001e28"
      color-link divider "#001e28,#d0d0d0"
      color-link error "#cb4b16,#001e28"
      color-link gutter-error "#cb4b16,#001e28"
      color-link gutter-warning "#fce94f,#001e28"
      color-link hlsearch "#ffffff,#005028"
      color-link identifier "#00c8a0,#001e28"
      color-link identifier.class "#00c8a0,#001e28"
      color-link indent-char "#a0a0a0,#001e28"
      color-link line-number "#a0a0a0,#001923"
      color-link preproc "bold #5aaae6,#001e28"
      color-link special "#a6e22e,#001e28"
      color-link statement "bold #5aaae6,#001e28"
      color-link statusline "#ffffff,#0078c8"
      color-link symbol "#00c8a0,#001e28"
      color-link symbol.brackets "#ffffff,#001e28"
      color-link symbol.tag "bold #5aaae6,#001e28"
      color-link tabbar "#001e28,#ffffff"
      color-link todo "#fce94f,#001e28"
      color-link type "bold #3cc83c,#001e28"
      color-link type.keyword "bold #5aaae6,#001e28"
      color-link type.extended "#ffffff,#001e28"
      color-link underlined "#608b4e,#001e28"
    '';
  };
}
