# shared/terminal/cli-tuis/micro/themes/dukelight-tc.nix
#
# =====================================================================
# MICRO: DUKELIGHT TC THEME
#
# - Dukelight TC theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "dukelight-tc"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.dukelight-tc;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.dukelight-tc.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Dukelight TC theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/dukelight-tc.micro".text = ''
      color-link color-column "#f0f0f0"
      color-link comment "#3f7f5f,#f0f0f0"
      color-link constant.bool "#641e00,#f0f0f0"
      color-link constant "#641e00,#f0f0f0"
      color-link constant.string "#0000ff,#f0f0f0"
      color-link constant.string.char "#0000ff,#f0f0f0"
      color-link constant.string.url "#0000ff,#f0f0f0"
      color-link current-line-number "bold #004080,#f0f0f0"
      color-link cursor-line "#e6e6e6"
      color-link default "#000000,#f0f0f0"
      color-link diff-added "#008040,#f0f0f0"
      color-link diff-modified "#641e00,#f0f0f0"
      color-link diff-deleted "#500000,#f0f0f0"
      color-link divider "#f0f0f0,#004080"
      color-link error "#500000,#f0f0f0"
      color-link gutter-error "#500000,#f0f0f0"
      color-link gutter-warning "#dcc800,#f0f0f0"
      color-link hlsearch "#000000,#b8d8e8"
      color-link identifier "bold #0078a0,#f0f0f0"
      color-link identifier.class "bold #0078a0,#f0f0f0"
      color-link indent-char "#404040,#f0f0f0"
      color-link line-number "#404040,#e6e6e6"
      color-link preproc "bold #780050,#f0f0f0"
      color-link special "bold #0078a0,#f0f0f0"
      color-link statement "bold #780050,#f0f0f0"
      color-link statusline "#ffffff,#0078c8"
      color-link symbol "bold #0078a0,#f0f0f0"
      color-link symbol.brackets "#000000,#f0f0f0"
      color-link symbol.tag "bold #780050,#f0f0f0"
      color-link tabbar "#f0f0f0,#004080"
      color-link todo "#dcc800,#f0f0f0"
      color-link type "bold #004080,#f0f0f0"
      color-link type.keyword "bold #780050,#f0f0f0"
      color-link type.extended "#000000,#f0f0f0"
      color-link underlined "#3f7f5f,#f0f0f0"
    '';
  };
}
