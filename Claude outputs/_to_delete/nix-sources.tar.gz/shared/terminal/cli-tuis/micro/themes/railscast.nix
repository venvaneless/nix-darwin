# shared/terminal/cli-tuis/micro/themes/railscast.nix
#
# =====================================================================
# MICRO: RAILSCAST THEME
#
# - Railscast theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "railscast"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.railscast;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.railscast.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Railscast theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/railscast.micro".text = ''
      color-link default "#e6e1dc,#2b2b2b"
      color-link comment "#bc9458,#2b2b2b"
      color-link statement "#cc7833,#2b2b2b"
      color-link constant "#a5c261,#2b2b2b"
      color-link constant.bool "#6d9cbe,#2b2b2b"
      color-link constant.specialChar "#459231,#2b2b2b"
      color-link type "#6d9cbe,#2b2b2b"
      color-link preproc "#cc7833,#2b2b2b"
      color-link special "#cc7833,#2b2b2b"
      color-link underlined "#cc7833,#2b2b2b"
      color-link todo "bold #cc7833,#2b2b2b"
      color-link error "bold #cc7833,#2b2b2b"
      color-link gutter-error "#cc7833,#11151C"
      color-link hlsearch "#e6e1dc,#474d5c"
      color-link indent-char "#414141,#2b2b2b"
      color-link line-number "#a1a1a1,#232323"
      color-link current-line-number "#e6e1dc,#2b2b2b"
      color-link diff-added "#00AF00"
      color-link diff-modified "#FFAF00"
      color-link diff-deleted "#D70000"
      color-link gutter-warning "#a5c261,#11151C"
      color-link symbol "#edb753,#2b2b2b"
      color-link symbol.operator "#cc7833,#2b2b2b"
      color-link symbol.brackets "#cc7833,#2b2b2b"
      color-link identifier "#edb753,#2b2b2b"
      color-link statusline "#b1b1b1,#232323"
      color-link tabbar "bold #b1b1b1,#232323"
      color-link cursor-line "#353535"
      color-link color-column "#353535"
      color-link space "underline #e6e1dc,#2b2b2b"

      #the Python syntax definition are wrong. This is not how you should do decorators!
      color-link brightgreen "#edb753,#2b2b2b"
    '';
  };
}
