# shared/terminal/cli-tuis/micro/themes/dracula-tc.nix
#
# =====================================================================
# MICRO: DRACULA TC THEME
#
# - Dracula TC theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "dracula-tc"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.dracula-tc;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.dracula-tc.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Dracula TC theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/dracula-tc.micro".text = ''
      color-link default "#F8F8F2,#282A36"
      color-link comment "#6272A4"

      color-link identifier "#50FA7B"
      color-link identifier.class "#8BE9FD"
      color-link identifier.var "#F8F8F2"

      color-link constant "#BD93F9"
      color-link constant.number "#F8F8F2"
      color-link constant.string "#F1FA8C"

      color-link symbol "#FF79C6"
      color-link symbol.brackets "#F8F8F2"
      color-link symbol.tag "#AE81FF"

      color-link type "italic #8BE9FD"
      color-link type.keyword "#FF79C6"

      color-link special "#FF79C6"
      color-link statement "#FF79C6"
      color-link preproc "#FF79C6"

      color-link underlined "#FF79C6"
      color-link error "bold #FF5555"
      color-link todo "bold #FF79C6"

      color-link hlsearch "#282A36,#50FA7B"

      color-link diff-added "#50FA7B"
      color-link diff-modified "#FFB86C"
      color-link diff-deleted "#FF5555"

      color-link gutter-error "#FF5555"
      color-link gutter-warning "#E6DB74"

      color-link statusline "#282A36,#F8F8F2"
      color-link tabbar "#282A36,#F8F8F2"
      color-link indent-char "#6272A4"
      color-link line-number "#6272A4"
      color-link current-line-number "#F8F8F2"

      color-link cursor-line "#44475A,#F8F8F2"
      color-link color-column "#44475A"
      color-link type.extended "default"
    '';
  };
}
