# shared/terminal/cli-tuis/micro/themes/atom-dark.nix
#
# =====================================================================
# MICRO: ATOM DARK THEME
#
# - Official Atom Dark theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "atom-dark"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.atom-dark;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.atom-dark.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the Atom-Dark theme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/atom-dark.micro".text = ''
      color-link default "#C5C8C6,#1D1F21"
      color-link comment "#7C7C7C,#1D1F21"
      color-link identifier "#F9EE98,#1D1F21"
      color-link constant "#FF73FD,#1D1F21"
      color-link constant.string "#A8FF60,#1D1F21"
      color-link statement "#96CBFE,#1D1F21"
      color-link symbol "#96CBFE,#1D1F21"
      color-link preproc "#62B1FE,#1D1F21"
      color-link type "#C6C5FE,#1D1F21"
      color-link special "#A6E22E,#1D1F21"
      color-link underlined "#D33682,#1D1F21"
      color-link error "bold #FF4444,#1D1F21"
      color-link todo "bold #FF8844,#1D1F21"
      color-link hlsearch "#000000,#B4EC85"
      color-link statusline "#1D1F21,#C5C8C6"
      color-link tabbar "#1D1F21,#C5C8C6"
      color-link indent-char "#505050,#1D1F21"
      color-link line-number "#656866,#232526"
      color-link current-line-number "#656866,#1D1F21"
      color-link diff-added "#00AF00"
      color-link diff-modified "#FFAF00"
      color-link diff-deleted "#D70000"
      color-link gutter-error "#FF4444,#1D1F21"
      color-link gutter-warning "#EEEE77,#1D1F21"
      color-link cursor-line "#2D2F31"
      color-link color-column "#2D2F31"
      #color-link symbol.brackets "#96CBFE,#1D1F21"
      #No extended types (bool in C, etc.)
      #color-link type.extended "default"
      #Plain brackets
    '';
  };
}
