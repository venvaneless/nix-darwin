# shared/terminal/cli-tuis/micro/themes/cmc-tc.nix
#
# =====================================================================
# MICRO: CAPTAINS MC-CLELLAN'S PERSONAL COLOUR SCHEME
#
# - Official CaptainMcClellan's personal theme for Micro
# - Selected directly in ../micro.nix with selectedTheme = "cmc-tc"
# =====================================================================

{ config, lib, ... }:

let
  microCfg = config.ven.features.terminal.cliTuis.micro;
  cfg = microCfg.themes.cmc-tc;
in
{
  options.ven.features.terminal.cliTuis.micro.themes.cmc-tc.enable = lib.mkOption {
    type = lib.types.bool;
    default = false;
    description = "Internal switch for the CaptainMcClellan's personal colour scheme selected in micro.nix.";
  };

  config = lib.mkIf (microCfg.enable && cfg.enable) {
    # Micro loads custom colour schemes from this XDG colourschemes directory.
    xdg.configFile."micro/colorschemes/cmc-tc.micro".text = ''
      #CaptainMcClellan's personal colour scheme.
      #Full colour edition.
      color-link default "#aaaaaa,#1e2124"
      color-link comment "bold #555555"
      color-link constant "#008888"
      #color-link constant.string "#888800"
      color-link constant.string "#a85700"
      color-link constant.specialChar "bold #ccccff"
      color-link identifier "bold #e34234"
      color-link identifier.macro "bold #e34234"
      color-link identifier.var "bold #5757ff"
      color-link identifier.class "bold #ffffff"
      color-link statement "bold #ffff55"
      color-link symbol "#722f37"
      color-link symbol.brackets "#4169e1"
      color-link symbol.tag "#5757ff"
      color-link preproc "bold #55ffff"
      color-link type "#3eb489"
      color-link type.keyword "bold #bdecb6"
      color-link special "#b57edc"
      color-link ignore "default"
      color-link error "bold ,#e34234"
      color-link todo "bold underline #888888,#f26522"
      color-link hlsearch "#b7b7b7,#32593d"
      color-link indent-char ",#bdecb6"
      color-link line-number "#bdecb6,#36393e"
      color-link line-number.scrollbar "#3eb489"
      color-link statusline "#aaaaaa,#8a496b"
      color-link tabbar "#aaaaaa,#8a496b"
      color-link current-line-number "bold #e34234,#424549"
      color-link current-line-number.scroller "red"
      color-link diff-added "#00AF00"
      color-link diff-modified "#FFAF00"
      color-link diff-deleted "#D70000"
      color-link gutter-error ",#e34234"
      color-link gutter-warning "#e34234"
      color-link color-column "#f26522"
      color-link constant.bool "bold #55ffff"
      color-link constant.bool.true "bold #85ff85"
      color-link constant.bool.false "bold #ff8585"
    '';
  };
}
